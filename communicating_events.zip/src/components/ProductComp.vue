<template>
    <div class="product">
        
        <div class="product-image">
          <img :src="image" />
        </div>
  
        <div class="product-info">
            <h1>{{ product }}</h1>
            <p v-if="inStock">In Stock</p>
            <p v-else>Out of Stock</p>
            <p>Shipping: {{ shipping }}</p>
  
            <ProductDetails :details="details"></ProductDetails>
  
            <div class="color-box"
                 v-for="(variant, index) in variants" 
                 :key="variant.variantId"
                 :style="{ backgroundColor: variant.variantColor }"
                 @mouseover="updateProduct(index)"
                 >
            </div> 
  
            <button v-on:click="addToCart" 
              :disabled="!inStock"
              :class="{ disabledButton: !inStock }"
              >
            Add to cart
            </button>
  
            <button @click="removeFromCart"
            >
          Remove from cart
          </button>
           
  
         </div>  
      
      </div>

</template>
<script>
import ProductDetails from './ProductDetails.vue'
export default{
    name:'ProductComp',
    components:{
       ProductDetails 
    },
    data() {
    return {
        product: 'Laptops',
        brand: 'HP',
        selectedVariant: 0,
        details: ['8GB RAM', '1 TB HDD', '11thGen'],
        variants: [
          {
            variantId: 2234,
            variantColor: 'black',
            variantImage:  'https://img6.gadgetsnow.com/gd/images/products/additional/large/G323009_View_1/computer-laptop/laptops/hp-pavilion-15-ec2150ax-amd-hexa-core-ryzen-5-5600h-15-6-inches-notebook-laptop-8gb-512gb-ssd-windows-11-black-2-93-kg-.jpg',
            variantQuantity: 10     
          },
          {
            variantId: 2235,
            variantColor: 'red',
            variantImage: 'https://in-media.apjonlinecdn.com/catalog/product/cache/b3b166914d87ce343d4dc5ec5117b502/6/V/6V2X7PA-1_T1680321026.png',
            variantQuantity: 0     
          }
        ],
        cart: 0
    }
  }, methods: {
      addToCart: function() {
        this.$emit('add-to-cart',this.variants[this.selectedVariant].variantId)
      },
      updateProduct: function(index) {  
          this.selectedVariant = index
      },
      removeFromCart: function() {
             this.$emit('remove-from-cart', this.variants[this.selectedVariant].variantId)
        }

    },
    computed: {
        title() {
            return this.brand + ' ' + this.product  
        },
        image(){
            return this.variants[this.selectedVariant].variantImage
        },
        inStock(){
            return this.variants[this.selectedVariant].variantQuantity
        },
        shipping() {
          if (this.prime) {
            return "Free"
          }
            return 180
        }
    },
    props: {
    prime: {
      type: Boolean,
      required: true
    }
  }
}
</script>
<style></style>