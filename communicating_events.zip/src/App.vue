<template>
  <div id="app">
    <ProductComp :prime="prime" @add-to-cart="updateCart"  
    @remove-from-cart="removeItem"></ProductComp>
    <div class="cart">
      <p>Cart({{ cart.length }})</p>
    </div>
  </div>
</template>

<script>

import ProductComp  from './components/ProductComp.vue'
export default {
  name: 'App',
  components: {
    ProductComp
  },
  data() {
    return{
      prime: true,
      cart:[]
    }     
    },
    methods: {
        updateCart(id) {
          //this.cart += 1
          this.cart.push(id);
          console.log(this.cart);
        },
        removeItem(id) {
          for(var i = this.cart.length - 1; i >= 0; i--) {
            if (this.cart[i] === id) {
               this.cart.splice(i, 1);
            }
          }
        }
      }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
